import pyautogui as p
import time


#countdown
print('3')
time.sleep(1)
print('2')
time.sleep(1)
print('1')
time.sleep(1)
print('lets crack!')

file = open('wordlist.txt', 'r') #wordlist of the possible password combinations
for raw in file: #read all wordlist
    
    #password cracking
    p.write(raw , interval=0.01)
    time.sleep(0.45)
    p.press('enter')
    time.sleep(0.45)
    p.click()
    
    
    print(raw)
    time.time()
   

#to this
print(file.readline())
